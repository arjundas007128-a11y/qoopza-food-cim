-- Qoopza Food: run this in Supabase Dashboard > SQL Editor.
-- Create the first admin user in Authentication > Users first, then copy that user's UUID.

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

-- Orders schema expected by admin.html. If you already have an orders table,
-- compare its columns before running; do not replace existing customer data.
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  customer_name text not null,
  phone text not null,
  address text not null,
  items jsonb not null default '[]'::jsonb,
  total numeric(10,2) not null default 0 check (total >= 0),
  payment_method text not null check (payment_method in ('UPI','Cash on Delivery')),
  status text not null default 'New' check (status in ('New','Confirmed','Preparing','Out for Delivery','Delivered','Cancelled')),
  created_at timestamptz not null default now()
);

alter table public.admin_users enable row level security;
alter table public.orders enable row level security;

-- Admin check is performed on the server; browser users cannot read admin_users.
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.admin_users
    where user_id = (select auth.uid())
  );
$$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

-- Customer can read only their own orders. Admin can read all orders.
drop policy if exists "customers read own orders" on public.orders;
create policy "customers read own orders" on public.orders
for select to authenticated
using (user_id = (select auth.uid()) or public.is_admin());

-- Customer checkout can insert only an order belonging to their own account.
drop policy if exists "customers create own orders" on public.orders;
create policy "customers create own orders" on public.orders
for insert to authenticated
with check (user_id = (select auth.uid()));

-- Only an authenticated admin can update order status/details.
drop policy if exists "admins update orders" on public.orders;
create policy "admins update orders" on public.orders
for update to authenticated
using (public.is_admin())
with check (public.is_admin());

-- No delete policy: orders cannot be deleted through the public client.
-- Add the first admin by replacing the UUID below with the Auth user's UUID:
-- insert into public.admin_users (user_id) values ('PASTE-AUTH-USER-UUID-HERE');
